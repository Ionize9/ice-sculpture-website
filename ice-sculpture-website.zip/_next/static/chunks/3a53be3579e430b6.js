__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/b4df0194c75cb7df.js",
  "static/chunks/turbopack-75926fa23835b02c.js"
])
