__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/b4df0194c75cb7df.js",
  "static/chunks/turbopack-87905e7fb7790ec7.js"
])
